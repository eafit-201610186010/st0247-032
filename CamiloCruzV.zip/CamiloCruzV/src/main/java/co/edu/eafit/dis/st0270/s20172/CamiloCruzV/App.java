package co.edu.eafit.dis.st0270.s20172.CamiloCruzV;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
