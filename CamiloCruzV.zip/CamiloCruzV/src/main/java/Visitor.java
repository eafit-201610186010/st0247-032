public interface Visitor {
    public void visit(AddNode add);
    public void visit(AsignNode asign);
    public void visit(ClearNode clear);
    public void visit(EpsilonNode epsilon);
    public void visit(FunctionNode fun);
    public void visit(MinusNode minus);
    public void visit(NumberNode num);
    public void visit(PlusNode plus);
    public void visit(ProgNode prog);
    public void visit(RecallNode recall);
    public void visit(TimesNode times);
    public void visit(ShiftLeftNode sl);
    public void visit(ShiftRightNode sr);
    public void visit(StoreNode store);
    public void visit(SubNode sub);
}
