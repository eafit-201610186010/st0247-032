//package co.edu.eafit.dis.expr.tokens;


public class DivToken extends Token {

    public DivToken() {
        super(-1,-1);
    }

    public DivToken(int linea, int column) {
        super(linea, column);
    }

    public boolean equals(Object obj) {
        boolean ret = false;
        if (obj instanceof DivToken) {
            return true;
        }
        return ret;
    }

    public String toString() {
        String str = super.toString();
        return "/ " + str;
    }

    public int hashCode() {
        return TokenInfo.DIV_TOKEN;
    }
}
