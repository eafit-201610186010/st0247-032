//package co.edu.eafit.dis.expr.tokens;

public class SeparatorToken extends Token {

    private String separator;

    public SeparatorToken(String separator, int linea, int column) {
        super(linea, column);
        this.separator = new String(separator);
    }

    public String toString() {
        return "Separator: " + separator + " " + super.toString();
    }
}
