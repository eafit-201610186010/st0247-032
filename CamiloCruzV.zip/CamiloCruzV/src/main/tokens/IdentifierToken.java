//package co.edu.eafit.dis.expr.tokens;

public class IdentifierToken extends Token {

    private String id;

    public IdentifierToken() {
        super(-1,-1);
        this.id = null;
    }

    public IdentifierToken(String id) {
        super(-1,-1);
        this.id = id;
    }

    public IdentifierToken(String id, int line, int column) {
        super(line,column);
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public String toString() {
        String str = super.toString();
        return "Identifier: " + id + " " + str;
    }

    public boolean equals(Object obj) {
        boolean ret = false;
        if (obj instanceof IdentifierToken) {
            return true;
        }
        return ret;
    }

    public int hashCode() {
        return TokenInfo.ID_TOKEN;
    }

}
