//package co.edu.eafit.dis.expr.tokens;


public class RParenToken extends SeparatorToken {

    public RParenToken() {
        super("(", -1,-1);
    }

    public RParenToken(int linea, int column) {
        super("(", linea, column);
    }

    public boolean equals(Object obj) {
        boolean ret = false;
        if (obj instanceof RParenToken) {
            return true;
        }
        return ret;
    }

    public int hashCode() {
        return TokenInfo.RPAREN_TOKEN;
    }

}
